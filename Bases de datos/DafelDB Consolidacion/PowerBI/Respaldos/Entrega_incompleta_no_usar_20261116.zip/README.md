# Power BI - Dafel

## Estado

La base `DafelDB` contiene una capa analitica de solo lectura en el esquema `bi`.
Las doce consultas del Excel quedaron representadas por las vistas
`bi.vw_01_Inventario` a `bi.vw_12_DemandaNoAtendida`.

El archivo `DafelDB_Dashboard.pbix` contiene 17 tablas importadas, una tabla
calculada `Medidas`, 41 relaciones activas en esquema estrella y 28 medidas
DAX validadas.

El PBIX contiene cuatro paginas terminadas. Las capturas de comprobacion estan
en la carpeta `Evidencias` y la explicacion individual de cada consulta se
encuentra en `GUIA_CONSULTAS_POWERBI.md`.

## Conexion local

- Servidor: `DESKTOP-5K1DA26\SQLEXPRESS`
- Base: `DafelDB`
- Modo recomendado: **Importar**
- Autenticacion local: **Windows**

En Power BI Desktop:

1. Seleccionar **Obtener datos > SQL Server**.
2. Escribir el servidor y la base indicados arriba.
3. Elegir **Importar**.
4. En el navegador, seleccionar el esquema `bi`.
5. Importar `DimFecha`, las cuatro vistas `vw_Dim*` y las doce vistas numeradas.
6. No importar directamente tablas `dbo`; la capa `bi` evita duplicaciones y expone nombres listos para presentar.

## Paginas implementadas

### 1. Resumen gerencial

- Segmentadores: anio, mes, cliente y ciudad.
- Tarjetas: valor vigente, recaudo neto, saldo pendiente, conversion comercial.
- Linea: valor y recaudo por mes.
- Barras: valor por cliente.
- Dona: valor vigente por estado operativo del alquiler.
- Tabla de detalle: alquiler, estado, cliente, valor vigente, pagos netos y saldo pendiente.

Esta pagina es el dashboard principal exigido para el unico integrante del grupo.

### 2. Inventario y disponibilidad

- Consultas 1, 2, 6, 11 y 12.
- Disponible estimado por categoria.
- Cantidades despachadas de reservas futuras por codigo.
- Unidades-dia de utilizacion por categoria.
- Cantidad inspeccionada por condicion resultante.
- Demanda faltante por codigo de recurso.

### 3. Comercial y operaciones

- Consultas 3, 4, 5 y 10.
- Valor propuesto de cotizaciones por estado.
- Dias de retraso por estado operativo.
- Cantidad pendiente de despacho por estado y obra.
- Cantidad afectada en incidencias por estado.

### 4. Liquidacion y recaudo

- Consultas 7, 8 y 9.
- Valor vigente por estado operativo.
- Saldo pendiente por cliente.
- Comparacion mensual entre valor vigente y recaudo neto.

## Relaciones recomendadas

Usar relaciones de uno a muchos y filtro en una direccion:

- `vw_DimCliente[id_cliente]` con las vistas que contienen `id_cliente`.
- `vw_DimObra[id_obra]` con las vistas que contienen `id_obra`.
- `vw_DimRecurso[id_recurso]` con las vistas que contienen `id_recurso`.
- `vw_DimEmpleado[id_empleado]` con `vw_11_Inspecciones[id_empleado]`.
- `DimFecha[fecha]` con la fecha principal de cada vista. Mantener una sola relacion activa por tabla.

Las vistas ya incluyen los nombres descriptivos; si una relacion resulta ambigua,
se puede omitir y usar directamente la dimension incluida en la vista.

Estas relaciones ya fueron implementadas y verificadas. El detalle se encuentra
en `RELACIONES_MODELO.md`.

## Archivos

- `Tema_Dafel.json`: tema visual para importar desde Power BI.
- `Medidas_DAX.md`: medidas para copiar al modelo.
- `Consultas_PowerQuery_M.pq`: referencia reproducible de las fuentes SQL.
- `Dashboard_Dafel_Especificacion.md`: distribucion y campos de cada visual.
- `GUIA_CONSULTAS_POWERBI.md`: explicacion funcional de las doce consultas.
- `Evidencias/*.png`: capturas de las cuatro paginas terminadas.

